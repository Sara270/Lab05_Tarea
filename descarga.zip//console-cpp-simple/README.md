# console-cpp-simple

# Developer Workspace

[![Contribute](http://beta.codenvy.com/factory/resources/codenvy-contribute.svg)](http://beta.codenvy.com/f?id=21w2nx87yto2xi1z)

# Recipe

FROM [codenvy/cpp_gcc](https://hub.docker.com/r/codenvy/cpp_gcc/)

# Commands

| #       | Description           | Command  |
| :------------- |:-------------| :-----|
| 1      | Build and run | `cd ${current.project.path} && make && ./a.out` |


# Output

The app will print Hello World to the console
